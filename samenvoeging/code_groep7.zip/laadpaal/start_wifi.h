#ifndef STARTWIFI_H
#define STARTWIFI_H

char* startWifi();

#endif
