/*
 * start_wifi.h
 *
 *  Created on: May 15, 2013
 *      Author: filip
 */

#ifndef START_WIFI_H_
#define START_WIFI_H_

char* startWifi();

#endif /* START_WIFI_H_ */
