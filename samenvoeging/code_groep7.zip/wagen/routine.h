#ifndef ROUTINE_H
#define ROUTINE_H

/*******************

Dit is de logica die op de 3de thread uitgevoerd moet worden. Deze moet wisselen tussen enerzijds het rijden en het laden. Afhankelijk van of de wagen aan de laadpaal hangt of niet.

*******************/

void *routine(void* arg);

#endif
