/*
 * gpio_test.h
 *
 *  Created on: May 19, 2013
 *      Author: filip
 */

#ifndef GPIO_TEST_H_
#define GPIO_TEST_H_

void setLEDS(int load);
int gpio_test();

void initLCD6();
void setLCD6();
void clrLCD6();

void initLCD7();
void setLCD7();
void clrLCD7();

void initLCD8();
void setLCD8();
void clrLCD8();

void initLCD9();
void setLCD9();
void clrLCD9();

void initLCD10();
void setLCD10();
void clrLCD10();

void initLCD11();
void setLCD11();
void clrLCD11();

void initLCD12();
void setLCD12();
void clrLCD12();

void initLCD13();
void setLCD13();
void clrLCD13();

void initLCD14();
void setLCD14();
void clrLCD14();

void initLCD15();
void setLCD15();
void clrLCD15();

void initLCD16();
void setLCD16();
void clrLCD16();

void initLCD17();
void setLCD17();
void clrLCD17();

void initLCD18();
void setLCD18();
void clrLCD18();
#endif /* GPIO_TEST_H_ */
