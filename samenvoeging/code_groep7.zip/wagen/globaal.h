#ifndef GLOBAAL_H
#define GLOBAAL_H
void init_connection();
char* upperhost;
int paalnummer;
int poort;
int bufferlengte;
int tekstlengte;
int poort_centrale_server;
char*  host_centrale_server;
int max_poort;
int max_laadpalen;
char* prefix;
int IPLengte;
char* me;
char* interface;
#endif
