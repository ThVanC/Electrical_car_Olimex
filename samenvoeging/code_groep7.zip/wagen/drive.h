#ifndef DRIVE_H
#define DRIVE_H

int moveLeft();
int moveRight();
int moveForward();
int speed(int s);
int initDrive();

#endif